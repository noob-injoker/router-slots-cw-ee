<template>
  <div>
    {{msg}}
    <button @click="update">改变父组件的值</button>
  </div>
</template>

<script lang='ts'>
import { defineComponent, reactive, toRefs, SetupContext } from 'vue'
interface Data {}
export default defineComponent({
  name: '',
  props: {
    msg: {
      type: String,
      default: ''
    }
  },
  components: {},
  setup(props, ctx: SetupContext) {
    console.log(ctx)
    let data: Data = reactive<Data>({})
    let update = ():void => {
      ctx.emit('update:msg', '改变之后的值')
    }
    return {
      ...toRefs(data),
      update
    }
  },
})
</script>

<style scoped lang='scss'>
</style>