<template>
    <!-- <div>
      {{name}} --- {{age}} --- {{sex}} --- {{num}} --- {{computedAge}}
    </div>
  
    <div ref="dvRef">123</div> -->
      <button @click="handleClick">按钮</button>
    <div>
      <input type="text" v-model="value">
    </div>
</template>

<script lang='ts'>
import {defineComponent, reactive, toRefs, onMounted, ref, Ref, computed, ComputedRef, watchEffect, watch} from 'vue'
import {useRouter} from 'vue-router'
// reactive是用来定义对象数据
// 用接口定义数据类型
interface Data {
  name: string,
  age: number,
  sex: string,
  value: string
}

export default defineComponent({
  name: 'Home',
  components: {

  },
  props: {

  },
  // 所有的逻辑代码都写在setup这个函数当中
  setup() {
    let router = useRouter()
    let data: Data = reactive<Data>({
      name: 'jack',
      age: 20,
      sex: '男',
      value: '123'
    })
    // ref用来定义简单数据类型和获取dom的ref
    let num: Ref<number> = ref<number>(10)
    let dvRef = ref<HTMLDivElement | null>(null)

    // 立即执行监听函数 并且在数据改变之后再次执行
    // 数据必须是reactive定义的
    // 返回值是停止监听函数
    // let stopWatchEffect =  watchEffect(() => {
    //   console.log(data.value)
    //   if (data.value === '123111') stopWatchEffect()
    // })

    onMounted(() => {
      // console.log(data.age)
      // console.log(dvRef.value)
    })

    let computedAge: ComputedRef<number> = computed(() => data.age + 20)

    // watch的第一个参数是箭头函数返回要监听的数据
    // 第二个参数也是箭头函数 参数是val和oldVal
    // watch也返回一个停止监听函数
    // 可以有多个watch
    // 也可以把多个wacth写成同一个
    let stopWatch =  watch(()=> data.value, (val, oldVal) => {
      console.log(val)
      console.log(oldVal)
      if (data.value === '123111') stopWatch()
    })

    watch(() => data.age, (val, oldVal) => {
      console.log(val)
      console.log(oldVal)
    })

    watch(() => [data.age, data.value], (val, oldVal) => {
      console.log(val)
      console.log(oldVal)
    })



    let handleClick = ():void => {
      // console.log(num.value)
      // alert(data.name)
      // data.age ++
      router.push({
        path: '/about',
        query: {
          name: data.name
        }
      })
    }

    return {
      ...toRefs(data),
      num,
      handleClick,
      dvRef,
      computedAge,
      stopWatch
      // stopWatchEffect
    }
  }
})
</script>

<style lang="scss" scoped>

</style>