import { defineComponent, reactive } from 'vue'
interface Data {
  name: string,
  arr: number[]
}
export default defineComponent({
  name: 'demo',
  components: {

  },
  props: {

  },
  setup(props, ctx) {
    let data: Data = reactive<Data>({
      name: 'jack',
      arr: [1, 2, 3, 4, 5]
    })
    let handleClick = () => {

    }
    return () => (
      <div>
        {
          data.arr.map((item: number) => {
            {item}
          })
        }
      </div>
    )
  }
})