import { createRouter, createWebHistory, RouteRecordRaw, createWebHashHistory, RouteLocationNormalized, NavigationGuardNext } from 'vue-router'
import Home from '../views/Home.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    meta: {
      title: '首页'
    }
  },
  {
    path: '/about',
    name: 'about',
    component: () => import('../views/About.vue')
  },
  {
    path: '/demo',
    name: 'demo',
    component: () => import('../views/Demo')
  }
]

// 决定路由模式
const isPro: boolean = process.env.NODE_ENV === 'production'

const router = createRouter({
  // history是路由模式
  history: isPro ? createWebHashHistory(process.env.BASE_URL) : createWebHistory(process.env.BASE_URL),
  routes
})

router.beforeEach((to:RouteLocationNormalized, from:RouteLocationNormalized, next: NavigationGuardNext) => {
  document.title = to.meta.title
  next()
})

export default router
