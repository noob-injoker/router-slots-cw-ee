import service from './index'

export default {
  // login({username, password}: {username: string, password: string}) {

  // },
  // getData({pagenum, pagesize, query}: {pagenum: number | string, pagesize: number | string, query?: string}) {
    
  // },
  getTopics() {
    return service.get('/topics')
  }
}